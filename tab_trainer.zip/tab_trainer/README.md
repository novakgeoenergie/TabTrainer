# Tab Trainer

Flutter app: paste JSON (notes from an AI that read your sheet-music photo, or ready tab JSON),
convert to guitar tab, save to local SQLite, practice with adjustable tempo.

## Build the APK via GitHub (no local setup)
1. Create a GitHub repo, push this folder to branch `main`.
2. Actions tab -> "Build APK" runs automatically (or "Run workflow").
3. Download artifact `tab-trainer-apk` -> unzip -> install `app-release.apk` on the phone.

## Build locally
    flutter create --platforms=android --project-name tab_trainer .
    flutter pub get
    flutter run            # or: flutter build apk --release

## Workflow
Import screen -> "Zkopírovat prompt" -> paste prompt + photo into Claude/ChatGPT ->
copy JSON answer -> "Vložit JSON" -> "Převést" -> check preview/warnings -> "Uložit".

samples/ode_to_joy_notes.json is a ready-to-paste test input.

## Player
- **Odpočet 5 s**: po Startu 5 s odpočet (s kliknutím) a pak se rozjede tabulatura.
- **Tóny**: aplikace přehrává noty tabulatury (syntetizované v Dartu), takže slyšíš, jak to má znít.
- **Metronom**: klik na každou dobu, přízvuk na začátku taktu.
Všechny tři jdou vypnout. Audio řeší balíček flutter_soloud (při buildu kompiluje nativní kód, první build trvá déle).
