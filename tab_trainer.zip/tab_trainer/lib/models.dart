import 'dart:convert';

/// MIDI numbers of open strings, index 0 = string 1 (high e) ... 5 = string 6 (low E)
const List<int> kOpenMidi = [64, 59, 55, 50, 45, 40];

/// string: 1 = high e ... 6 = low E (standard tab convention)
class TabNote {
  final int string;
  final int fret;
  final double beat; // position inside the measure, in quarter-note beats
  final double duration; // in quarter-note beats
  final bool uncertain;

  /// Sounding pitch (MIDI) of this tab note.
  int get midi => kOpenMidi[string - 1] + fret;

  const TabNote({
    required this.string,
    required this.fret,
    required this.beat,
    required this.duration,
    this.uncertain = false,
  });

  Map<String, dynamic> toJson() => {
        'string': string,
        'fret': fret,
        'beat': beat,
        'duration': duration,
        if (uncertain) 'uncertain': true,
      };

  factory TabNote.fromJson(Map<String, dynamic> j) => TabNote(
        string: (j['string'] as num).toInt(),
        fret: (j['fret'] as num).toInt(),
        beat: (j['beat'] as num?)?.toDouble() ?? 0,
        duration: (j['duration'] as num?)?.toDouble() ?? 1,
        uncertain: j['uncertain'] == true,
      );
}

class TabMeasure {
  final double beats;
  final List<TabNote> notes;
  const TabMeasure({required this.beats, required this.notes});

  Map<String, dynamic> toJson() => {
        'beats': beats,
        'notes': notes.map((n) => n.toJson()).toList(),
      };

  factory TabMeasure.fromJson(Map<String, dynamic> j) => TabMeasure(
        beats: (j['beats'] as num).toDouble(),
        notes: (j['notes'] as List)
            .map((n) => TabNote.fromJson(n as Map<String, dynamic>))
            .toList(),
      );
}

class Song {
  final int? id;
  final String title;
  final String? artist;
  final int bpm;
  final String timeSignature;
  final List<TabMeasure> measures;
  final DateTime createdAt;

  Song({
    this.id,
    required this.title,
    this.artist,
    required this.bpm,
    required this.timeSignature,
    required this.measures,
    required this.createdAt,
  });

  double get totalBeats => measures.fold(0.0, (s, m) => s + m.beats);
  int get noteCount => measures.fold(0, (s, m) => s + m.notes.length);

  String encodeData() => jsonEncode({
        'time_signature': timeSignature,
        'measures': measures.map((m) => m.toJson()).toList(),
      });

  Map<String, Object?> toRow() => {
        'title': title,
        'artist': artist,
        'bpm': bpm,
        'data': encodeData(),
        'created_at': createdAt.millisecondsSinceEpoch,
      };

  factory Song.fromRow(Map<String, Object?> r) {
    final data = jsonDecode(r['data'] as String) as Map<String, dynamic>;
    return Song(
      id: r['id'] as int,
      title: r['title'] as String,
      artist: r['artist'] as String?,
      bpm: r['bpm'] as int,
      timeSignature: data['time_signature'] as String? ?? '4/4',
      measures: (data['measures'] as List)
          .map((m) => TabMeasure.fromJson(m as Map<String, dynamic>))
          .toList(),
      createdAt: DateTime.fromMillisecondsSinceEpoch(r['created_at'] as int),
    );
  }
}
