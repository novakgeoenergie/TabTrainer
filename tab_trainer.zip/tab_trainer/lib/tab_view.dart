import 'package:flutter/material.dart';
import 'models.dart';

const kStringColors = [
  Color(0xFFFF6B6B),
  Color(0xFFFFA94D),
  Color(0xFFFFD43B),
  Color(0xFF69DB7C),
  Color(0xFF4DABF7),
  Color(0xFFCC5DE8),
];
const kStringNames = ['e', 'B', 'G', 'D', 'A', 'E'];
const double kTabHeight = 270;

/// Tab renderer. [pos] = position in quarter-note beats from the song start.
/// The cursor stays at ~28 % of the width and the tab scrolls under it.
class TabView extends StatelessWidget {
  final Song song;
  final double pos;
  final double pxPerBeat;
  final ValueChanged<double>? onScrubBeats;

  const TabView({
    super.key,
    required this.song,
    required this.pos,
    this.pxPerBeat = 64,
    this.onScrubBeats,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onHorizontalDragUpdate: onScrubBeats == null
          ? null
          : (d) => onScrubBeats!(-d.delta.dx / pxPerBeat),
      child: SizedBox(
        height: kTabHeight,
        width: double.infinity,
        child: CustomPaint(painter: _TabPainter(song, pos, pxPerBeat)),
      ),
    );
  }
}

class _TabPainter extends CustomPainter {
  final Song song;
  final double pos;
  final double ppb;
  _TabPainter(this.song, this.pos, this.ppb);

  static const double top = 34;
  static const double rowH = 34;
  static const Color bg = Color(0xFF111113);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.clipRect(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, Paint()..color = bg);

    final cursorX = size.width * 0.28;
    final bottom = top + rowH * 6;

    for (var i = 0; i < 6; i++) {
      final y = top + rowH * (i + 0.5);
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        Paint()
          ..color = kStringColors[i].withAlpha(64)
          ..strokeWidth = 1.0 + i * 0.25,
      );
    }

    canvas.save();
    canvas.translate(cursorX - pos * ppb, 0);
    final viewL = pos * ppb - cursorX - 60;
    final viewR = viewL + size.width + 120;
    final barPaint = Paint()
      ..color = const Color(0xFF3A3A40)
      ..strokeWidth = 1.5;

    double start = 0;
    var idx = 0;
    for (final m in song.measures) {
      idx++;
      final x0 = start * ppb;
      final x1 = (start + m.beats) * ppb;
      if (x1 >= viewL && x0 <= viewR) {
        canvas.drawLine(Offset(x0, top), Offset(x0, bottom), barPaint);
        _text(canvas, '$idx', Offset(x0 + 4, top - 20), 10, const Color(0xFF777777));
        for (final n in m.notes) {
          final nb = start + n.beat;
          final x = nb * ppb;
          final y = top + rowH * (n.string - 1 + 0.5);
          final color = kStringColors[n.string - 1];
          final active = pos >= nb && pos < nb + (n.duration < 0.5 ? 0.5 : n.duration);
          final rect = RRect.fromRectAndRadius(
            Rect.fromCenter(center: Offset(x, y), width: 28, height: 22),
            const Radius.circular(6),
          );
          canvas.drawRRect(rect, Paint()..color = active ? color : bg);
          canvas.drawRRect(
            rect,
            Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = n.uncertain ? 2 : 1
              ..color = n.uncertain
                  ? const Color(0xFFFF922B)
                  : color.withAlpha(active ? 255 : 130),
          );
          _text(canvas, '${n.fret}', Offset(x, y), 13,
              active ? Colors.black : color, bold: true, centered: true);
        }
      }
      start += m.beats;
    }
    canvas.drawLine(
      Offset(start * ppb, top),
      Offset(start * ppb, bottom),
      Paint()
        ..color = const Color(0xFF666666)
        ..strokeWidth = 4,
    );
    canvas.restore();

    // fixed string labels
    canvas.drawRect(Rect.fromLTWH(0, top - 4, 26, rowH * 6 + 8), Paint()..color = bg);
    for (var i = 0; i < 6; i++) {
      _text(canvas, kStringNames[i], Offset(13, top + rowH * (i + 0.5)), 13,
          kStringColors[i], bold: true, centered: true);
    }

    canvas.drawLine(
      Offset(cursorX, top - 8),
      Offset(cursorX, bottom + 8),
      Paint()
        ..color = Colors.white.withAlpha(110)
        ..strokeWidth = 2,
    );
  }

  void _text(Canvas c, String s, Offset o, double size, Color color,
      {bool bold = false, bool centered = false}) {
    final tp = TextPainter(
      text: TextSpan(
        text: s,
        style: TextStyle(
          fontSize: size,
          color: color,
          fontWeight: bold ? FontWeight.w700 : FontWeight.w400,
          fontFamily: 'monospace',
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(c, centered ? o - Offset(tp.width / 2, tp.height / 2) : o);
  }

  @override
  bool shouldRepaint(covariant _TabPainter old) =>
      old.pos != pos || old.song != song || old.ppb != ppb;
}
