import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import 'audio.dart';
import 'converter.dart';
import 'db.dart';
import 'models.dart';
import 'prompt.dart';
import 'tab_view.dart';

void main() => runApp(const TabTrainerApp());

class TabTrainerApp extends StatelessWidget {
  const TabTrainerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tab Trainer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF4DABF7),
        scaffoldBackgroundColor: const Color(0xFF0D0D0F),
      ),
      home: const LibraryScreen(),
    );
  }
}

// ───────────────────────── Library ─────────────────────────

const _demoTab = '''
{
  "title": "Demo riff 0-3-5",
  "bpm": 100,
  "time_signature": "4/4",
  "measures": [
    {"notes": [
      {"string": 4, "fret": 0, "beat": 0, "duration": 1},
      {"string": 4, "fret": 3, "beat": 1, "duration": 1},
      {"string": 4, "fret": 5, "beat": 2, "duration": 2}]},
    {"notes": [
      {"string": 4, "fret": 0, "beat": 0, "duration": 1},
      {"string": 4, "fret": 3, "beat": 1, "duration": 1},
      {"string": 4, "fret": 6, "beat": 2, "duration": 0.5},
      {"string": 4, "fret": 5, "beat": 2.5, "duration": 1.5}]},
    {"notes": [
      {"string": 4, "fret": 0, "beat": 0, "duration": 1},
      {"string": 4, "fret": 3, "beat": 1, "duration": 1},
      {"string": 4, "fret": 5, "beat": 2, "duration": 2}]},
    {"notes": [
      {"string": 4, "fret": 3, "beat": 0, "duration": 1},
      {"string": 4, "fret": 0, "beat": 1, "duration": 3}]}
  ]
}''';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});
  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  List<Song> _songs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await SongDb.all();
    if (!mounted) return;
    setState(() {
      _songs = s;
      _loading = false;
    });
  }

  Future<void> _openImport() async {
    final added = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => const ImportScreen()),
    );
    if (added == true) _load();
  }

  Future<void> _addDemo() async {
    await SongDb.insert(importSong(_demoTab).song);
    _load();
  }

  Future<bool> _confirmDelete(Song s) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Smazat tabulaturu?'),
        content: Text(s.title),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Zrušit')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Smazat')),
        ],
      ),
    );
    return ok == true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Moje tabulatury')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openImport,
        icon: const Icon(Icons.add),
        label: const Text('Import'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _songs.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('Zatím nic. Naimportuj noty nebo tabulaturu.'),
                      const SizedBox(height: 12),
                      OutlinedButton(onPressed: _addDemo, child: const Text('Přidat ukázku')),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _songs.length,
                  itemBuilder: (ctx, i) {
                    final s = _songs[i];
                    return Dismissible(
                      key: ValueKey(s.id),
                      direction: DismissDirection.endToStart,
                      confirmDismiss: (_) => _confirmDelete(s),
                      onDismissed: (_) {
                        SongDb.delete(s.id!);
                        setState(() => _songs.removeAt(i));
                      },
                      background: Container(
                        color: Colors.red.shade900,
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 20),
                        child: const Icon(Icons.delete),
                      ),
                      child: ListTile(
                        leading: const Icon(Icons.music_note),
                        title: Text(s.title),
                        subtitle: Text([
                          if (s.artist != null) s.artist!,
                          '${s.bpm} BPM',
                          '${s.measures.length} taktů',
                        ].join(' · ')),
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => PlayerScreen(song: s)),
                          );
                          _load();
                        },
                      ),
                    );
                  },
                ),
    );
  }
}

// ───────────────────────── Import ─────────────────────────

class ImportScreen extends StatefulWidget {
  const ImportScreen({super.key});
  @override
  State<ImportScreen> createState() => _ImportScreenState();
}

class _ImportScreenState extends State<ImportScreen> {
  final _title = TextEditingController();
  final _artist = TextEditingController();
  final _json = TextEditingController();
  bool _guitarNotation = true;
  ImportResult? _result;
  String? _error;

  @override
  void dispose() {
    _title.dispose();
    _artist.dispose();
    _json.dispose();
    super.dispose();
  }

  void _convert() {
    try {
      final r = importSong(
        _json.text,
        title: _title.text,
        artist: _artist.text,
        guitarNotation: _guitarNotation,
      );
      setState(() {
        _result = r;
        _error = null;
      });
    } on ImportException catch (e) {
      setState(() {
        _result = null;
        _error = e.message;
      });
    } catch (e) {
      setState(() {
        _result = null;
        _error = 'Chyba při převodu: $e';
      });
    }
  }

  Future<void> _save() async {
    final r = _result;
    if (r == null) return;
    await SongDb.insert(r.song);
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final r = _result;
    return Scaffold(
      appBar: AppBar(title: const Text('Import')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _title,
            decoration: const InputDecoration(labelText: 'Název (volitelné)', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _artist,
            decoration: const InputDecoration(labelText: 'Autor (volitelné)', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.copy),
                  label: const Text('Zkopírovat prompt'),
                  onPressed: () async {
                    await Clipboard.setData(const ClipboardData(text: llmPrompt));
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Prompt je ve schránce. Vlož ho do AI spolu s fotkou not.')),
                    );
                  },
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.paste),
                  label: const Text('Vložit JSON'),
                  onPressed: () async {
                    final d = await Clipboard.getData(Clipboard.kTextPlain);
                    if (d?.text != null) setState(() => _json.text = d!.text!);
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _json,
            minLines: 6,
            maxLines: 10,
            style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
            decoration: const InputDecoration(
              labelText: 'JSON z AI (noty nebo hotová tabulatura)',
              alignLabelWithHint: true,
              border: OutlineInputBorder(),
            ),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Noty psané pro kytaru'),
            subtitle: const Text('Kytarový zápis je o oktávu výš, než zní. Vypni pro klavírní/zpěvní noty.'),
            value: _guitarNotation,
            onChanged: (v) => setState(() => _guitarNotation = v),
          ),
          const SizedBox(height: 8),
          FilledButton(onPressed: _convert, child: const Text('Převést na tabulaturu')),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(_error!, style: TextStyle(color: Colors.red.shade300)),
            ),
          if (r != null) ...[
            const SizedBox(height: 16),
            Text('${r.song.title} · ${r.song.measures.length} taktů · ${r.song.noteCount} not · ${r.song.bpm} BPM',
                style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            Card(
              clipBehavior: Clip.antiAlias,
              child: _PreviewTab(song: r.song),
            ),
            if (r.warnings.isNotEmpty) ...[
              const SizedBox(height: 8),
              for (final w in r.warnings)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.warning_amber, size: 16, color: Color(0xFFFF922B)),
                      const SizedBox(width: 6),
                      Expanded(child: Text(w, style: const TextStyle(fontSize: 13))),
                    ],
                  ),
                ),
            ],
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: const Text('Uložit do knihovny'),
            ),
          ],
        ],
      ),
    );
  }
}

/// Draggable preview so you can check the conversion before saving.
class _PreviewTab extends StatefulWidget {
  final Song song;
  const _PreviewTab({required this.song});
  @override
  State<_PreviewTab> createState() => _PreviewTabState();
}

class _PreviewTabState extends State<_PreviewTab> {
  double _pos = 0;
  @override
  Widget build(BuildContext context) {
    return TabView(
      song: widget.song,
      pos: _pos,
      pxPerBeat: 56,
      onScrubBeats: (d) => setState(() => _pos = (_pos + d).clamp(0.0, widget.song.totalBeats)),
    );
  }
}

// ───────────────────────── Player ─────────────────────────

class _Ev {
  final double beat;
  final int midi;
  const _Ev(this.beat, this.midi);
}

class PlayerScreen extends StatefulWidget {
  final Song song;
  const PlayerScreen({super.key, required this.song});
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen>
    with SingleTickerProviderStateMixin {
  static const double _countInSeconds = 5;

  late final Ticker _ticker;
  final AudioEngine _audio = AudioEngine();
  final List<_Ev> _events = [];
  final Set<int> _measureStarts = {};
  int _nextEv = 0;

  Duration _last = Duration.zero;
  double _pos = 0;
  late int _bpm;
  bool _playing = false;
  bool _countIn = true;
  bool _sound = true;
  bool _click = true;
  double _countLeft = 0;
  int _lastClickBeat = -1;
  bool _audioReady = false;
  String? _audioError;

  Song get song => widget.song;

  @override
  void initState() {
    super.initState();
    _bpm = song.bpm;
    _ticker = createTicker(_onTick);

    double start = 0;
    for (final m in song.measures) {
      _measureStarts.add(start.floor());
      for (final n in m.notes) {
        _events.add(_Ev(start + n.beat, n.midi));
      }
      start += m.beats;
    }
    _events.sort((a, b) => a.beat.compareTo(b.beat));
    _initAudio();
  }

  Future<void> _initAudio() async {
    try {
      await _audio.init(_events.map((e) => e.midi).toSet());
      if (!mounted) {
        _audio.dispose();
        return;
      }
      setState(() => _audioReady = true);
    } catch (e) {
      if (mounted) setState(() => _audioError = 'Zvuk se nepodařilo spustit: $e');
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    _audio.dispose();
    super.dispose();
  }

  int _seekIndex(double pos) {
    var i = 0;
    while (i < _events.length && _events[i].beat < pos - 1e-6) {
      i++;
    }
    return i;
  }

  void _resetPositionState() {
    _nextEv = _seekIndex(_pos);
    _lastClickBeat = _pos == _pos.floorToDouble() ? _pos.floor() - 1 : _pos.floor();
  }

  void _onTick(Duration elapsed) {
    var dt = (elapsed - _last).inMicroseconds / 1e6;
    _last = elapsed;

    // Count-in phase
    if (_countLeft > 0) {
      final before = _countLeft.ceil();
      _countLeft -= dt;
      if (_countLeft > 0) {
        if (_countLeft.ceil() != before) _audio.click();
        setState(() {});
        return;
      }
      dt = -_countLeft; // leftover time goes to the song
      _countLeft = 0;
    }

    final next = _pos + dt * _bpm / 60.0;
    if (next >= song.totalBeats) {
      _pause();
      setState(() => _pos = 0);
      _resetPositionState();
      return;
    }

    // Metronome
    final b = next.floor();
    if (b != _lastClickBeat) {
      _lastClickBeat = b;
      if (_click) _audio.click(accent: _measureStarts.contains(b));
    }

    // Tones: fire every note whose beat has been reached (chords together)
    final batch = <int>[];
    while (_nextEv < _events.length && _events[_nextEv].beat <= next + 1e-9) {
      batch.add(_events[_nextEv].midi);
      _nextEv++;
    }
    if (_sound && batch.isNotEmpty) {
      final vol = 0.6 / math.sqrt(batch.length);
      for (final m in batch) {
        _audio.note(m, volume: vol);
      }
    }

    setState(() => _pos = next);
  }

  void _play() {
    if (_ticker.isActive) return;
    _last = Duration.zero;
    _resetPositionState();
    _countLeft = _countIn ? _countInSeconds : 0;
    if (_countIn) _audio.click(accent: true);
    _ticker.start();
    setState(() => _playing = true);
  }

  void _pause() {
    if (_ticker.isActive) _ticker.stop();
    _countLeft = 0;
    if (mounted) setState(() => _playing = false);
  }

  void _restart() {
    setState(() => _pos = 0);
    _resetPositionState();
  }

  void _setBpm(int v, {bool persist = true}) {
    final b = v.clamp(30, 300);
    setState(() => _bpm = b);
    if (persist && song.id != null) SongDb.updateBpm(song.id!, b);
  }

  String _measureLabel() {
    double start = 0;
    for (var i = 0; i < song.measures.length; i++) {
      final end = start + song.measures[i].beats;
      if (_pos < end) return '${i + 1} / ${song.measures.length}';
      start = end;
    }
    return '${song.measures.length} / ${song.measures.length}';
  }

  @override
  Widget build(BuildContext context) {
    final total = song.totalBeats;
    return Scaffold(
      appBar: AppBar(title: Text(song.title)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              clipBehavior: Clip.antiAlias,
              child: Stack(
                children: [
                  TabView(
                    song: song,
                    pos: _pos,
                    onScrubBeats: (d) {
                      setState(() => _pos = (_pos + d).clamp(0.0, total));
                      _resetPositionState();
                    },
                  ),
                  if (_countLeft > 0)
                    Positioned.fill(
                      child: Container(
                        color: Colors.black54,
                        alignment: Alignment.center,
                        child: Text(
                          '${_countLeft.ceil()}',
                          style: const TextStyle(fontSize: 96, fontWeight: FontWeight.w800),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: LinearProgressIndicator(value: total == 0 ? 0 : _pos / total),
                ),
                const SizedBox(width: 12),
                Text('Takt ${_measureLabel()}', style: const TextStyle(fontSize: 12)),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                const Text('TEMPO', style: TextStyle(letterSpacing: 3, fontSize: 12)),
                Text('$_bpm BPM', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w700)),
              ],
            ),
            Slider(
              value: _bpm.clamp(30, 300).toDouble(),
              min: 30,
              max: 300,
              divisions: 270,
              onChanged: (v) => _setBpm(v.round(), persist: false),
              onChangeEnd: (v) => _setBpm(v.round()),
            ),
            Wrap(
              spacing: 8,
              children: [
                for (final p in [50, 75, 100, 125])
                  ChoiceChip(
                    label: Text(p == 100 ? 'Originál' : '$p %'),
                    selected: _bpm == (song.bpm * p / 100).round(),
                    onSelected: (_) => _setBpm((song.bpm * p / 100).round()),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: _restart, icon: const Icon(Icons.skip_previous), iconSize: 32),
                const SizedBox(width: 16),
                IconButton.filled(
                  onPressed: _playing ? _pause : _play,
                  icon: Icon(_playing ? Icons.pause : Icons.play_arrow),
                  iconSize: 44,
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              alignment: WrapAlignment.center,
              children: [
                FilterChip(
                  label: const Text('Odpočet 5 s'),
                  selected: _countIn,
                  onSelected: (v) => setState(() => _countIn = v),
                ),
                FilterChip(
                  label: const Text('Tóny'),
                  selected: _sound,
                  onSelected: (v) => setState(() => _sound = v),
                ),
                FilterChip(
                  label: const Text('Metronom'),
                  selected: _click,
                  onSelected: (v) => setState(() => _click = v),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (_audioError != null)
              Text(_audioError!, style: TextStyle(color: Colors.red.shade300, fontSize: 12))
            else if (!_audioReady)
              const Text('Připravuji zvuk…', textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
