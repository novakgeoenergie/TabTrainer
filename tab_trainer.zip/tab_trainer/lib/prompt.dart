const String llmPrompt = '''
You are an expert in music notation (OMR). Read the attached sheet-music image and return ONLY valid JSON (no markdown, no commentary) in exactly this shape:

{
  "title": "...",
  "time_signature": "4/4",
  "tempo_bpm": 100,
  "measures": [
    { "notes": [
        { "pitch": "E4", "duration": "quarter" },
        { "pitch": "G4", "duration": "eighth", "dotted": true },
        { "rest": true, "duration": "half" },
        { "pitches": ["C4", "E4", "G4"], "duration": "quarter" },
        { "pitch": "F#4", "duration": "quarter", "uncertain": true }
    ] }
  ]
}

Rules:
- One object per measure, in reading order. Include every note and rest so the durations in each measure add up to the time signature.
- pitch = note name + octave exactly as written on the staff in the clef shown (middle C = C4). A treble clef with a small 8 below counts as a plain treble clef. Use # and b for accidentals; apply the key signature and earlier accidentals in the measure.
- duration: whole, half, quarter, eighth, 16th, 32nd. Add "dotted": true for dotted notes.
- Chords: use "pitches". Rests: "rest": true.
- Write tied notes as separate notes.
- If unsure about a note, give your best guess and add "uncertain": true.
- Ignore lyrics, chord symbols and any existing tablature.
''';
