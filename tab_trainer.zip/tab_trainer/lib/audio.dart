import 'package:flutter_soloud/flutter_soloud.dart';
import 'synth.dart';

/// Thin wrapper around SoLoud: synthesizes guitar-like tones and clicks in
/// memory, then plays them with low latency (polyphonic).
class AudioEngine {
  static bool _engineStarted = false;
  static int _gen = 0;

  final int _id = _gen++;
  final Map<int, dynamic> _notes = {};
  dynamic _clickSrc;
  dynamic _accentSrc;
  bool ready = false;

  Future<void> init(Set<int> midis) async {
    if (!_engineStarted) {
      await SoLoud.instance.init();
      _engineStarted = true;
    }
    _clickSrc = await SoLoud.instance.loadMem(
      'p${_id}_click.wav',
      clickWav(accent: false),
      mode: LoadMode.memory,
    );
    _accentSrc = await SoLoud.instance.loadMem(
      'p${_id}_accent.wav',
      clickWav(accent: true),
      mode: LoadMode.memory,
    );
    for (final m in midis) {
      _notes[m] = await SoLoud.instance.loadMem(
        'p${_id}_n$m.wav',
        pluckWav(m),
        mode: LoadMode.memory,
      );
    }
    ready = true;
  }

  void note(int midi, {double volume = 0.5}) {
    final s = _notes[midi];
    if (!ready || s == null) return;
    try {
      SoLoud.instance.play(s, volume: volume);
    } catch (_) {}
  }

  void click({bool accent = false}) {
    final s = accent ? _accentSrc : _clickSrc;
    if (!ready || s == null) return;
    try {
      SoLoud.instance.play(s, volume: accent ? 0.9 : 0.6);
    } catch (_) {}
  }

  void dispose() {
    ready = false;
    final all = <dynamic>[
      ..._notes.values,
      if (_clickSrc != null) _clickSrc,
      if (_accentSrc != null) _accentSrc,
    ];
    _notes.clear();
    for (final s in all) {
      Future.sync(() => SoLoud.instance.disposeSource(s)).catchError((_) {});
    }
  }
}
