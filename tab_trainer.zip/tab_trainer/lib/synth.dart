import 'dart:math';
import 'dart:typed_data';

const int kSampleRate = 22050;

Uint8List _wav(Float64List samples) {
  final n = samples.length;
  final bd = ByteData(44 + n * 2);
  void tag(int o, String t) {
    for (var i = 0; i < 4; i++) {
      bd.setUint8(o + i, t.codeUnitAt(i));
    }
  }

  tag(0, 'RIFF');
  bd.setUint32(4, 36 + n * 2, Endian.little);
  tag(8, 'WAVE');
  tag(12, 'fmt ');
  bd.setUint32(16, 16, Endian.little);
  bd.setUint16(20, 1, Endian.little); // PCM
  bd.setUint16(22, 1, Endian.little); // mono
  bd.setUint32(24, kSampleRate, Endian.little);
  bd.setUint32(28, kSampleRate * 2, Endian.little);
  bd.setUint16(32, 2, Endian.little);
  bd.setUint16(34, 16, Endian.little);
  tag(36, 'data');
  bd.setUint32(40, n * 2, Endian.little);
  for (var i = 0; i < n; i++) {
    final v = (samples[i].clamp(-1.0, 1.0) * 32767).round();
    bd.setInt16(44 + i * 2, v, Endian.little);
  }
  return bd.buffer.asUint8List();
}

/// Plucked-string-like tone via additive synthesis (exact pitch, higher
/// partials decay faster). [midi] is the sounding pitch (A4 = 69 = 440 Hz).
Uint8List pluckWav(int midi, {double seconds = 2.2}) {
  final f = 440.0 * pow(2.0, (midi - 69) / 12.0);
  final n = (kSampleRate * seconds).round();
  final out = Float64List(n);
  final maxK = min(10, ((kSampleRate / 2) / f).floor());
  final amps = <double>[];
  var sum = 0.0;
  for (var k = 1; k <= maxK; k++) {
    final a = 1.0 / pow(k, 1.1);
    amps.add(a);
    sum += a;
  }
  const tau1 = 1.2;
  for (var k = 1; k <= maxK; k++) {
    final a = amps[k - 1] / sum;
    final tau = tau1 / (1 + 0.8 * (k - 1));
    final w = 2 * pi * f * k / kSampleRate;
    for (var i = 0; i < n; i++) {
      out[i] += a * exp(-(i / kSampleRate) / tau) * sin(w * i);
    }
  }
  final attack = (kSampleRate * 0.003).round();
  final fade = (kSampleRate * 0.3).round();
  for (var i = 0; i < n; i++) {
    var g = 0.8;
    if (i < attack) g *= i / attack;
    if (i > n - fade) g *= (n - i) / fade;
    out[i] *= g;
  }
  return _wav(out);
}

/// Short metronome tick.
Uint8List clickWav({bool accent = false}) {
  final f = accent ? 1500.0 : 1000.0;
  final n = (kSampleRate * 0.05).round();
  final out = Float64List(n);
  for (var i = 0; i < n; i++) {
    final t = i / kSampleRate;
    out[i] = 0.9 * exp(-t / 0.012) * sin(2 * pi * f * t);
  }
  return _wav(out);
}
