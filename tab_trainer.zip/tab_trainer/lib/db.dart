import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'models.dart';

class SongDb {
  static Database? _db;

  static Future<Database> get _database async {
    final existing = _db;
    if (existing != null) return existing;
    final db = await openDatabase(
      p.join(await getDatabasesPath(), 'tabs.db'),
      version: 1,
      onCreate: (db, _) => db.execute('''
        CREATE TABLE songs(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          artist TEXT,
          bpm INTEGER NOT NULL,
          data TEXT NOT NULL,
          created_at INTEGER NOT NULL
        )'''),
    );
    _db = db;
    return db;
  }

  static Future<List<Song>> all() async {
    final db = await _database;
    final rows = await db.query('songs', orderBy: 'created_at DESC');
    return rows.map(Song.fromRow).toList();
  }

  static Future<int> insert(Song s) async {
    final db = await _database;
    return db.insert('songs', s.toRow());
  }

  static Future<void> updateBpm(int id, int bpm) async {
    final db = await _database;
    await db.update('songs', {'bpm': bpm}, where: 'id = ?', whereArgs: [id]);
  }

  static Future<void> delete(int id) async {
    final db = await _database;
    await db.delete('songs', where: 'id = ?', whereArgs: [id]);
  }
}
