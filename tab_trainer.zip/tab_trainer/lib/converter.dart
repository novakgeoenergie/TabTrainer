import 'dart:convert';
import 'dart:math';
import 'models.dart';

/// MIDI numbers of open strings, index 0 = string 1 (high e) ... 5 = string 6 (low E)
const List<int> _openMidi = [64, 59, 55, 50, 45, 40];
const int _maxFret = 20;
const double _eps = 0.01;

class ImportResult {
  final Song song;
  final List<String> warnings;
  ImportResult(this.song, this.warnings);
}

class ImportException implements Exception {
  final String message;
  ImportException(this.message);
  @override
  String toString() => message;
}

class _Pos {
  final int string;
  final int fret;
  const _Pos(this.string, this.fret);
}

num _num(dynamic v, num def) =>
    v is num ? v : (v is String ? (num.tryParse(v) ?? def) : def);

String _stripFences(String s) {
  var t = s.trim();
  if (t.startsWith('```')) {
    final nl = t.indexOf('\n');
    if (nl != -1) t = t.substring(nl + 1);
    t = t.trimRight();
    if (t.endsWith('```')) t = t.substring(0, t.length - 3);
  }
  return t.trim();
}

/// Accepts either:
///  * notes JSON (pitch/pitches/midi + duration names)  -> converted to tab
///  * tab JSON (string/fret/beat/duration)              -> used as is
/// [guitarNotation]: written pitch is an octave above sounding pitch
/// (standard for guitar scores). Only applies to notes JSON.
ImportResult importSong(
  String raw, {
  String? title,
  String? artist,
  bool guitarNotation = true,
}) {
  final warnings = <String>[];
  dynamic decoded;
  try {
    decoded = jsonDecode(_stripFences(raw));
  } on FormatException catch (e) {
    throw ImportException('Neplatný JSON: ${e.message}');
  }
  if (decoded is! Map<String, dynamic>) {
    throw ImportException('Očekávám JSON objekt s polem "measures".');
  }
  final j = decoded;
  final measuresRaw = j['measures'];
  if (measuresRaw is! List || measuresRaw.isEmpty) {
    throw ImportException('Chybí pole "measures" (nebo je prázdné).');
  }

  final sig = (j['time_signature'] ?? '4/4').toString();
  final sigBeats = _beatsPerMeasure(sig, warnings);
  final bpm = _num(j['tempo_bpm'] ?? j['bpm'], 100).toInt().clamp(30, 300);

  final isTab = measuresRaw.any((m) =>
      m is Map &&
      m['notes'] is List &&
      (m['notes'] as List).any((n) => n is Map && n.containsKey('fret')));

  final measures = isTab
      ? _parseTab(measuresRaw, sigBeats, warnings)
      : _parseNotes(measuresRaw, sigBeats, guitarNotation, warnings);

  final fallbackTitle = (j['title'] ?? 'Bez názvu').toString();
  final jsonArtist = j['artist']?.toString();
  final song = Song(
    title: (title != null && title.trim().isNotEmpty)
        ? title.trim()
        : fallbackTitle,
    artist: (artist != null && artist.trim().isNotEmpty)
        ? artist.trim()
        : jsonArtist,
    bpm: bpm,
    timeSignature: sig,
    measures: measures,
    createdAt: DateTime.now(),
  );
  return ImportResult(song, warnings);
}

double _beatsPerMeasure(String sig, List<String> w) {
  final p = sig.split('/');
  final n = p.length == 2 ? int.tryParse(p[0].trim()) : null;
  final d = p.length == 2 ? int.tryParse(p[1].trim()) : null;
  if (n == null || d == null || d == 0) {
    w.add('Neznámý takt "$sig", použito 4/4.');
    return 4.0;
  }
  return n * 4.0 / d;
}

List<TabMeasure> _parseTab(List raw, double sigBeats, List<String> w) {
  final out = <TabMeasure>[];
  for (final m in raw) {
    if (m is! Map) continue;
    final notes = <TabNote>[];
    double end = 0;
    final list = m['notes'];
    for (final n in (list is List ? list : const [])) {
      if (n is! Map) continue;
      final s = _num(n['string'], 0).toInt();
      final f = _num(n['fret'], -1).toInt();
      if (s < 1 || s > 6 || f < 0 || f > 24) {
        w.add('Takt ${out.length + 1}: neplatná struna/pražec ($s/$f), přeskočeno.');
        continue;
      }
      final beat = _num(n['beat'], 0).toDouble();
      final dur = _num(n['duration'], 1).toDouble();
      notes.add(TabNote(
        string: s,
        fret: f,
        beat: beat,
        duration: dur,
        uncertain: n['uncertain'] == true,
      ));
      end = max(end, beat + dur);
    }
    out.add(TabMeasure(beats: max(sigBeats, end), notes: notes));
  }
  return out;
}

List<TabMeasure> _parseNotes(
    List raw, double sigBeats, bool guitar, List<String> w) {
  final out = <TabMeasure>[];
  var lastFret = 4.0;
  var shifted = 0;
  var uncertainCount = 0;
  var truncatedChords = 0;

  final measureMaps = raw.whereType<Map>().toList();
  for (var mi = 0; mi < measureMaps.length; mi++) {
    final m = measureMaps[mi];
    final notes = <TabNote>[];
    double pos = 0;
    final list = m['notes'];
    for (final n in (list is List ? list : const [])) {
      if (n is! Map) continue;
      final dur = _duration(n, w, mi + 1);
      final midis = _midis(n, w, mi + 1);
      if (midis.isNotEmpty) {
        var adj = <int>[];
        for (var midi in midis) {
          if (guitar) midi -= 12;
          while (midi < 40) {
            midi += 12;
            shifted++;
          }
          while (midi > 84) {
            midi -= 12;
            shifted++;
          }
          adj.add(midi);
        }
        if (adj.length > 6) {
          adj = adj.sublist(0, 6);
          truncatedChords++;
        }
        final unc = n['uncertain'] == true;
        if (unc) uncertainCount++;
        final picks = _assign(adj, lastFret);
        for (final p in picks) {
          notes.add(TabNote(
            string: p.string,
            fret: p.fret,
            beat: pos,
            duration: dur,
            uncertain: unc,
          ));
        }
        final fretted = picks.where((p) => p.fret > 0).map((p) => p.fret).toList();
        if (fretted.isNotEmpty) {
          lastFret = fretted.reduce((a, b) => a + b) / fretted.length;
        }
      }
      pos += dur;
    }
    out.add(TabMeasure(beats: max(sigBeats, pos), notes: notes));

    // Sanity check - a great detector of OCR/LLM mistakes
    if (pos > sigBeats + _eps) {
      w.add('Takt ${mi + 1}: délky not dávají ${_fmt(pos)} dob místo ${_fmt(sigBeats)}.');
    } else if (pos < sigBeats - _eps && mi != 0 && mi != measureMaps.length - 1) {
      w.add('Takt ${mi + 1}: délky not dávají jen ${_fmt(pos)} dob z ${_fmt(sigBeats)}.');
    }
  }
  if (shifted > 0) {
    w.add('$shifted not bylo mimo rozsah kytary a posunuto o oktávu.');
  }
  if (truncatedChords > 0) {
    w.add('$truncatedChords akordů mělo víc než 6 tónů, zkráceno.');
  }
  if (uncertainCount > 0) {
    w.add('$uncertainCount not je označeno jako nejistých (oranžový rámeček).');
  }
  return out;
}

String _fmt(double v) =>
    v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(2);

double _duration(Map n, List<String> w, int measureNo) {
  if (n['duration_beats'] is num) {
    return (n['duration_beats'] as num).toDouble();
  }
  var d = (n['duration'] ?? 'quarter')
      .toString()
      .toLowerCase()
      .replaceAll('_', ' ')
      .replaceAll('-', ' ')
      .trim();
  var dotted = n['dotted'] == true;
  if (d.startsWith('dotted')) {
    dotted = true;
    d = d.substring(6).trim();
  }
  if (d.endsWith('.')) {
    dotted = true;
    d = d.substring(0, d.length - 1).trim();
  }
  const base = {
    'whole': 4.0,
    'half': 2.0,
    'quarter': 1.0,
    'eighth': 0.5,
    '16th': 0.25,
    'sixteenth': 0.25,
    '32nd': 0.125,
  };
  final b = base[d];
  if (b == null) {
    w.add('Takt $measureNo: neznámá délka "$d", použita čtvrťová.');
    return dotted ? 1.5 : 1.0;
  }
  return dotted ? b * 1.5 : b;
}

List<int> _midis(Map n, List<String> w, int measureNo) {
  if (n['rest'] == true) return [];
  final out = <int>[];
  void addPitch(dynamic p) {
    final s = p.toString();
    final m = _parsePitch(s);
    if (m != null) {
      out.add(m);
    } else if (s.toLowerCase() != 'rest') {
      w.add('Takt $measureNo: nerozpoznaná nota "$s".');
    }
  }

  if (n['pitches'] is List) {
    for (final p in n['pitches'] as List) {
      addPitch(p);
    }
  } else if (n['pitch'] != null) {
    addPitch(n['pitch']);
  } else if (n['midi'] is num) {
    out.add((n['midi'] as num).toInt());
  }
  return out;
}

int? _parsePitch(String s) {
  final m = RegExp(r'^([A-Ga-g])([#b♯♭]?)(-?\d)$').firstMatch(s.trim());
  if (m == null) return null;
  const base = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11};
  var semi = base[m.group(1)!.toUpperCase()]!;
  final acc = m.group(2);
  if (acc == '#' || acc == '♯') {
    semi++;
  } else if (acc == 'b' || acc == '♭') {
    semi--;
  }
  return 12 * (int.parse(m.group(3)!) + 1) + semi;
}

/// Picks string/fret for one note or a chord (brute force, max 6 notes).
/// Cost = distance from the previous hand position + small penalty for high
/// frets + penalty for wide chord spans. Open strings are cheap.
List<_Pos> _assign(List<int> midis, double ref) {
  List<_Pos>? best;
  var bestCost = double.infinity;
  final cur = <_Pos>[];

  void rec(int i, int used) {
    if (i == midis.length) {
      final c = _cost(cur, ref);
      if (c < bestCost) {
        bestCost = c;
        best = List<_Pos>.of(cur);
      }
      return;
    }
    for (var s = 0; s < 6; s++) {
      if ((used & (1 << s)) != 0) continue;
      final f = midis[i] - _openMidi[s];
      if (f < 0 || f > _maxFret) continue;
      cur.add(_Pos(s + 1, f));
      rec(i + 1, used | (1 << s));
      cur.removeLast();
    }
  }

  rec(0, 0);
  final found = best;
  if (found != null) return found;

  // Fallback (chord that cannot be fingered): place what fits greedily.
  final res = <_Pos>[];
  var used = 0;
  for (final m in midis) {
    for (var s = 0; s < 6; s++) {
      final f = m - _openMidi[s];
      if ((used & (1 << s)) == 0 && f >= 0 && f <= _maxFret) {
        res.add(_Pos(s + 1, f));
        used |= 1 << s;
        break;
      }
    }
  }
  return res;
}

double _cost(List<_Pos> ps, double ref) {
  double c = 0;
  for (final p in ps) {
    c += p.fret == 0 ? 1.0 : (p.fret - ref).abs();
    c += p.fret * 0.15;
  }
  final fretted = ps.where((p) => p.fret > 0).map((p) => p.fret).toList();
  if (fretted.length > 1) {
    final span = fretted.reduce(max) - fretted.reduce(min);
    c += span * 2.0 + (span > 4 ? 10 : 0);
  }
  return c;
}
